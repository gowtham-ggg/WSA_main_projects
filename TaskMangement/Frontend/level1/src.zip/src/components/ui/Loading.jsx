import React from 'react'

const Loading = () => {
  return (
    <section className='loading-screen'>Loading........</section>
  )
}

export default Loading
