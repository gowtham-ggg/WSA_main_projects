import React from 'react'

const Copyright = () => {
  return (
    <>
    <p className='getting-started-copyright-text'>
        ` &copy; 2025 <a style={{color : "purple"}} href="https://gowthamgportfolio.netlify.app/">Gowtham</a>. All rights Reserved `
    </p>
    </>
  )
}

export default Copyright
